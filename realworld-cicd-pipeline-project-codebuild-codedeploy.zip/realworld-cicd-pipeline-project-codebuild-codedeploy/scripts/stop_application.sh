#!/bin/bash
systemctl stop tomcat