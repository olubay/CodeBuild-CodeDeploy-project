#!/bin/bash
amazon-linux-extras install tomcat8.5 -y
systemctl enable tomcat